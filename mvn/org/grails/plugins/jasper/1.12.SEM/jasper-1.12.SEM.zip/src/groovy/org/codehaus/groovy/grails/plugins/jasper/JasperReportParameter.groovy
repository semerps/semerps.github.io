package org.codehaus.groovy.grails.plugins.jasper

class JasperReportParameter {

	String name
	
	String description
	
	Class<?> valueClass

	String valueClassName
	
	Class<?> nestedType
	
	String nestedTypeName
}
