package sem.cache

class SemCacheService {
    def redisService


    def setCacheStore(Class clazz,def key, def value) {
        redisService.memoize(key) {
            value
        }
    }

    def getCacheStore( def key){
         redisService[key]
    }

    def removeCacheStore(def key){
        redisService.deleteKeysWithPattern(key)
    }

}
