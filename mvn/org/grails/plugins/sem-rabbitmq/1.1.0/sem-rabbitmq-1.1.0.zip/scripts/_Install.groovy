
ant.mkdir(dir: "${basedir}/grails-app/rabbit-consumers")
ant.mkdir(dir: "${basedir}/grails-app/rabbit-converters")
