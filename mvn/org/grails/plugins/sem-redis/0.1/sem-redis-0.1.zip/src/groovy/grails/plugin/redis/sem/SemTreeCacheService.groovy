package grails.plugin.redis.sem

import org.redisson.api.RedissonClient

class SemTreeCacheService {
    RedissonClient redisson
}
