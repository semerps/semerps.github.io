package grails.plugin.redis.sem.util

import grails.plugin.redis.sem.SemTreeCacheManager
import grails.plugin.redis.sem.SemTreeCacheService
import org.redisson.Redisson
import org.redisson.client.codec.Codec
import org.redisson.codec.JsonJacksonCodec
import org.redisson.spring.cache.CacheConfig
import org.springframework.beans.factory.annotation.Value
import org.springframework.core.io.Resource
import org.redisson.api.RedissonClient
import org.redisson.config.Config

class RedisConfigurationUtil {
    def redisConfig = application.config.grails.sem.redis.config ?: [:]

    static def configurateSpringRedis = { @Value("classpath:/redisson.yaml") Resource configFile->
        Config config = Config.fromYAML(configFile.getInputStream())
        RedissonClient redissonClient = Redisson.create(config)
        Map<String, CacheConfig> mapConfig = new HashMap<String, CacheConfig>()
        mapConfig.put("sem", new CacheConfig())
        Codec jsonCodec = new JsonJacksonCodec();

        "semTreeCacheService"(SemTreeCacheService){
            redisson = redissonClient
        }
        "semTreeCacheManager"(SemTreeCacheManager){
            redisson = redissonClient
            configMap = mapConfig
            codec = jsonCodec
        }
    }
}
