package grails.plugin.redis.sem


import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.redisson.api.RMapCache;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.Codec;
import org.redisson.spring.cache.CacheConfig;
import org.redisson.spring.cache.RedissonCache;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.ResourceLoader;


class SemTreeCacheManager implements CacheManager, ResourceLoaderAware, InitializingBean {
    ResourceLoader resourceLoader
    private boolean dynamic
    private boolean allowNullValues
    Codec codec
    RedissonClient redisson
    Map<String, CacheConfig> configMap
    ConcurrentMap<String, Cache> instanceMap

    public SemTreeCacheManager() {
        this.instanceMap = new ConcurrentHashMap()
        this.dynamic = true
        this.allowNullValues = true
    }

    void afterPropertiesSet() throws Exception {
    }

    Cache getCache(String name) {
        Cache cache = this.instanceMap.get(name)
        if (!cache.is(null) || !this.dynamic) return cache
        CacheConfig cacheConfig = this.configMap.get(name)
        if (cacheConfig.is(null)) {
            (cacheConfig = new CacheConfig()) as Cache
            this.configMap.put(name, cacheConfig) as Cache
        }
        return this.createMapCache(name,cacheConfig)

    }

    private Cache createMapCache(String name, CacheConfig config){
        RMapCache<Object,Object> mapCache = this.getMapCache(name,config)
        Cache cache = new RedissonCache(mapCache,config,this.allowNullValues)
        Cache oldCache = this.instanceMap.putIfAbsent(name,cache)
        if(!oldCache.is(null))
            cache = oldCache
        else
            mapCache.setMaxSize(config.getMaxSize())
        return cache
    }

    protected RMapCache<Object,Object> getMapCache(String name, CacheConfig cacheConfig){
        return this.codec != null ? this.redisson.getMapCache(name,this.codec) : this.redisson.getMapCache(name)
    }

    Collection<String> getCacheNames() {
        return Collections.unmodifiableSet(this.configMap.keySet())
    }

    void setResourceLoader(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader
    }
}