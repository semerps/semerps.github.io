import grails.plugin.cache.CacheBeanPostProcessor
import grails.plugin.cache.ConfigLoader
import grails.plugin.cache.CustomCacheKeyGenerator
import grails.plugin.cache.web.filter.DefaultWebKeyGenerator
import grails.plugin.cache.web.filter.ExpressionEvaluator
import grails.plugin.cache.web.filter.simple.MemoryPageFragmentCachingFilter
import grails.plugin.redis.SemTreeCacheManager
import org.redisson.Redisson
import org.redisson.client.codec.Codec
import org.redisson.config.Config
import org.redisson.spring.cache.CacheConfig
import org.springframework.cache.CacheManager
import org.springframework.core.Ordered
import org.springframework.web.filter.DelegatingFilterProxy

import java.util.concurrent.ConcurrentHashMap

@org.springframework.cache.annotation.CacheConfig(cacheManager = "semTreeCacheManager")
class SemRedisGrailsPlugin {
    // the plugin version
    def version = "1.0.2"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "2.5 > *"
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp"
    ]

    // TODO Fill in these fields
    def title = "Sem Redis Plugin" // Headline display name of the plugin
    def author = "Aydın Öztürk"
    def authorEmail = "aydin.ozturk@uzmar.net"
    def description = '''\
Brief summary/description of the plugin.
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugin/sem-redis"

    // Extra (optional) plugin metadata

    // License: one of 'APACHE', 'GPL2', 'GPL3'
    def license = "APACHE"

    // Details of company behind the plugin (if there is one)
    def organization = [name: "UZMAR Teknoloji", url: "http://uzmar.tech"]

    // Any additional developers beyond the author specified above.
    def developers = [[name: "Aydın ÖZTÜRK", email: "aydin.ozturk@uzmar.net"]]

    // Location of the plugin's issue tracker.
//    def issueManagement = [ system: "JIRA", url: "http://jira.grails.org/browse/GPMYPLUGIN" ]

    // Online location of the plugin's browseable source code.
//    def scm = [ url: "http://svn.codehaus.org/grails-plugins/" ]

    def doWithWebDescriptor = {xml ->


        def filters = xml.filter
        def lastFilter = filters[filters.size() - 1]
        lastFilter + {
            filter {
                'filter-name'('grailsCacheFilter')
                'filter-class'(DelegatingFilterProxy.name)
                'init-param' {
                    'param-name'('targetFilterLifecycle')
                    'param-value'('true')
                }
            }
        }

        def filterMappings = xml.'filter-mapping'
        def lastMapping = filterMappings[filterMappings.size() - 1]
        lastMapping + {
            'filter-mapping' {
                'filter-name'('grailsCacheFilter')
                'url-pattern'('*.dispatch')
                'dispatcher'('FORWARD')
                'dispatcher'('INCLUDE')
            }
        }
    }


    def doWithSpring = {
        def redisConfiguration = application.config.grails.plugin.sem.redis.configuration
        if(redisConfiguration){
            Config config = Config.fromYAML(new File(redisConfiguration?:"redisson.yaml"))
            Map<String, CacheConfig> mapConfig = new HashMap<String, CacheConfig>()
            mapConfig.put(application.config.grails.plugin.sem.redis.mapKey?:"sem", new CacheConfig())
            ClassLoader classLoader = getClass().getClassLoader()
            Class<Codec> codecClass = classLoader.loadClass(application.config.grails.plugin.sem.redis.codecClass?:"org.redisson.codec.JsonJacksonCodec") as Class<Codec>
            Codec jsonCodec = codecClass.newInstance()

            "semTreeCacheManager"(SemTreeCacheManager) {
                redisson = Redisson.create(config)
                configMap = mapConfig
                codec = jsonCodec
                dynamic = true
                allowNullValues = true
                instanceMap = new ConcurrentHashMap()
            }

            def cacheConfig = application.config.grails.cache
            def proxyTargetClass = cacheConfig.proxyTargetClass
            if (!(proxyTargetClass instanceof Boolean)) proxyTargetClass = false
            def order = cacheConfig.aopOrder
            if (!(order instanceof Number)) order = Ordered.LOWEST_PRECEDENCE
            // allow user can to use their own key generator.
            def cacheKeyGen = cacheConfig.keyGenerator ?: 'customCacheKeyGenerator'
            customCacheKeyGenerator(CustomCacheKeyGenerator)

            xmlns cache: 'http://www.springframework.org/schema/cache'

            cache.'annotation-driven'('cache-manager': 'semTreeCacheManager' ,'key-generator': cacheKeyGen,
                    mode: 'proxy', order: order, 'proxy-target-class': proxyTargetClass)

            cacheBeanPostProcessor(CacheBeanPostProcessor)

            grailsCacheConfigLoader(ConfigLoader)

            webCacheKeyGenerator(DefaultWebKeyGenerator)

            webExpressionEvaluator(ExpressionEvaluator)

            "grailsCacheFilter"(MemoryPageFragmentCachingFilter) {
                cacheManager =         ref('semTreeCacheManager')
                cacheOperationSource = ref('cacheOperationSource')
                keyGenerator =         ref('webCacheKeyGenerator')
                expressionEvaluator =  ref('webExpressionEvaluator')
            }

        }

    }

    def doWithDynamicMethods = { ctx ->
        // TODO Implement registering dynamic methods to classes (optional)
    }

    def doWithApplicationContext = { ctx ->
        // TODO Implement post initialization spring config (optional)


    }

    def onChange = { event ->
        // TODO Implement code that is executed when any artefact that this plugin is
        // watching is modified and reloaded. The event contains: event.source,
        // event.application, event.manager, event.ctx, and event.plugin.
    }

    def onConfigChange = { event ->
        // TODO Implement code that is executed when the project configuration changes.
        // The event is the same as for 'onChange'.
    }

    def onShutdown = { event ->
        // TODO Implement code that is executed when the application shuts down (optional)
    }
}
