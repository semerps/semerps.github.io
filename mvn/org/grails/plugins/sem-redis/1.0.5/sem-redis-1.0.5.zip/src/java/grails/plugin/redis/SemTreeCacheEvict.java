package grails.plugin.redis;

import org.codehaus.groovy.transform.GroovyASTTransformationClass;

import java.lang.annotation.*;

/**
 * @author aydinozturk
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
@GroovyASTTransformationClass("grails.plugin.redis.SemTreeCacheTransformation")
public @interface SemTreeCacheEvict {

    String[] value();

    String key() default "";

    String condition() default "";

    boolean allEntries() default false;

    boolean beforeInvocation() default false;

    String cacheManager() default "semTreeCacheManager";
}
