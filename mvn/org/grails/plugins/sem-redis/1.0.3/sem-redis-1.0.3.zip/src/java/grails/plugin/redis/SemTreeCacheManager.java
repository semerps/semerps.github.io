package grails.plugin.redis;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentMap;
import org.redisson.api.RMap;
import org.redisson.api.RMapCache;
import org.redisson.api.RedissonClient;
import org.redisson.client.codec.Codec;
import org.redisson.spring.cache.CacheConfig;
import org.redisson.spring.cache.RedissonCache;
import org.springframework.beans.factory.BeanDefinitionStoreException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

public class SemTreeCacheManager implements CacheManager, ResourceLoaderAware, InitializingBean {
    ResourceLoader resourceLoader;
    private boolean dynamic;
    private boolean allowNullValues;
    Codec codec;
    RedissonClient redisson;
    Map<String, CacheConfig> configMap;
    ConcurrentMap<String, Cache> instanceMap;
    String configLocation;

    public void setConfigMap(Map<String, CacheConfig> configMap) {
        this.configMap = configMap;
    }

    public void setDynamic(boolean dynamic) {
        this.dynamic = dynamic;
    }

    public void setInstanceMap(ConcurrentMap<String, Cache> instanceMap) {
        this.instanceMap = instanceMap;
    }

    public void setAllowNullValues(boolean allowNullValues) {
        this.allowNullValues = allowNullValues;
    }

    public void setCacheNames(Collection<String> names) {
        if (names != null) {
            Iterator var2 = names.iterator();

            while (var2.hasNext()) {
                String name = (String) var2.next();
                this.getCache(name);
            }

            this.dynamic = false;
        } else {
            this.dynamic = true;
        }

    }

    public void setConfigLocation(String configLocation) {
        this.configLocation = configLocation;
    }

    public void setConfig(Map<String, ? extends CacheConfig> config) {
        this.configMap = (Map<String, CacheConfig>) config;
    }

    public void setRedisson(RedissonClient redisson) {
        this.redisson = redisson;
    }

    public void setCodec(Codec codec) {
        this.codec = codec;
    }

    protected CacheConfig createDefaultConfig() {
        return new CacheConfig();
    }

    public Cache getCache(String name) {
        Cache cache = (Cache) this.instanceMap.get(name);
        if (cache != null) {
            return cache;
        } else if (!this.dynamic) {
            return cache;
        } else {
            CacheConfig config = (CacheConfig) this.configMap.get(name);
            if (config == null) {
                config = this.createDefaultConfig();
                this.configMap.put(name, config);
            }

            return config.getMaxIdleTime() == 0L && config.getTTL() == 0L && config.getMaxSize() == 0 ? this.createMap(name, config) : this.createMapCache(name, config);
        }
    }

    private Cache createMap(String name, CacheConfig config) {
        RMap<Object, Object> map = this.getMap(name, config);
        Cache cache = new RedissonCache(map, this.allowNullValues);
        Cache oldCache = (Cache) this.instanceMap.putIfAbsent(name, cache);
        if (oldCache != null) {
            cache = oldCache;
        }

        return (Cache) cache;
    }

    protected RMap<Object, Object> getMap(String name, CacheConfig config) {
        return this.codec != null ? this.redisson.getMap(name, this.codec) : this.redisson.getMap(name);
    }

    private Cache createMapCache(String name, CacheConfig config) {
        RMapCache<Object, Object> map = this.getMapCache(name, config);
        Cache cache = new RedissonCache(map, config, this.allowNullValues);
        Cache oldCache = (Cache) this.instanceMap.putIfAbsent(name, cache);
        if (oldCache != null) {
            cache = oldCache;
        } else {
            map.setMaxSize(config.getMaxSize());
        }

        return cache;
    }

    protected RMapCache<Object, Object> getMapCache(String name, CacheConfig config) {
        return this.codec != null ? this.redisson.getMapCache(name, this.codec) : this.redisson.getMapCache(name);
    }

    public Collection<String> getCacheNames() {
        return Collections.unmodifiableSet(this.configMap.keySet());
    }

    public void setResourceLoader(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    public void afterPropertiesSet() throws Exception {
        if (this.configLocation != null) {
            Resource resource = this.resourceLoader.getResource(this.configLocation);

            try {
                this.configMap = (Map<String, CacheConfig>) (Map<String, CacheConfig>) CacheConfig.fromJSON(resource.getInputStream());
            } catch (IOException var5) {
                try {
                    this.configMap = (Map<String, CacheConfig>) CacheConfig.fromYAML(resource.getInputStream());
                } catch (IOException var4) {
                    throw new BeanDefinitionStoreException("Could not parse cache configuration at [" + this.configLocation + "]", var4);
                }
            }

        }
    }
}
