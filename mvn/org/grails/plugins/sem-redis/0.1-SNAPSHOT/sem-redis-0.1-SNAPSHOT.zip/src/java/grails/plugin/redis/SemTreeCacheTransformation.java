package grails.plugin.redis;

import grails.util.CollectionUtils;
import org.codehaus.groovy.ast.ASTNode;
import org.codehaus.groovy.ast.AnnotatedNode;
import org.codehaus.groovy.ast.AnnotationNode;
import org.codehaus.groovy.ast.ClassNode;
import org.codehaus.groovy.ast.expr.Expression;
import org.codehaus.groovy.control.CompilePhase;
import org.codehaus.groovy.control.SourceUnit;
import org.codehaus.groovy.transform.ASTTransformation;
import org.codehaus.groovy.transform.GroovyASTTransformation;

import java.util.Map;

/**
 * @author aydinozturk
 */
@GroovyASTTransformation(phase = CompilePhase.CANONICALIZATION)
public class SemTreeCacheTransformation implements ASTTransformation {

    @SuppressWarnings("unchecked")
    protected static final Map<ClassNode, ClassNode> GRAILS_ANNOTATION_CLASS_NODE_TO_SPRING_ANNOTATION_CLASS_NODE = CollectionUtils.<ClassNode, ClassNode>newMap(
            new ClassNode(grails.plugin.redis.SemTreeCacheable.class),  new ClassNode(org.springframework.cache.annotation.Cacheable.class),
            new ClassNode(grails.plugin.redis.SemTreeCacheEvict.class),   new ClassNode(org.springframework.cache.annotation.CacheEvict.class));

    public void visit(final ASTNode[] astNodes, final SourceUnit sourceUnit) {
        final ASTNode firstNode = astNodes[0];
        final ASTNode secondNode = astNodes[1];
        if (!(firstNode instanceof AnnotationNode) || !(secondNode instanceof AnnotatedNode)) {
            throw new RuntimeException("Internal error: wrong types: " + firstNode.getClass().getName() +
                    " / " + secondNode.getClass().getName());
        }

        final AnnotationNode grailsCacheAnnotationNode = (AnnotationNode) firstNode;
        final AnnotatedNode annotatedNode = (AnnotatedNode) secondNode;
        final AnnotationNode springCacheAnnotationNode = getCorrespondingSpringAnnotation(
                grailsCacheAnnotationNode);
        annotatedNode.addAnnotation(springCacheAnnotationNode);
    }

    protected AnnotationNode getCorrespondingSpringAnnotation(final AnnotationNode grailsCacheAnnotationNode) {
        final Map<String, Expression> grailsAnnotationMembers = grailsCacheAnnotationNode.getMembers();

        final ClassNode springCacheAnnotationClassNode = GRAILS_ANNOTATION_CLASS_NODE_TO_SPRING_ANNOTATION_CLASS_NODE.get(
                grailsCacheAnnotationNode.getClassNode());
        final AnnotationNode springCacheAnnotationNode = new AnnotationNode(springCacheAnnotationClassNode);
        for (Map.Entry<String, Expression> entry : grailsAnnotationMembers.entrySet()) {
            springCacheAnnotationNode.addMember(entry.getKey(), entry.getValue());
        }
        return springCacheAnnotationNode;
    }
}
