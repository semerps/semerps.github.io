package grails.plugin.sem

import grails.converters.JSON
import grails.plugins.sem.SemApiKeyToken
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import org.springframework.security.core.Authentication
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter

import javax.servlet.http.HttpServletRequest

class SemApiKeyHeaderAuthenticationProcessingFilter extends AbstractPreAuthenticatedProcessingFilter {
    static final Log logger = LogFactory.getLog(getClass());

    private String principalRequestHeader = "Authorization"

    SemApiKeyRSAManager semApiKeyRSAManager

    @Override
    protected Object getPreAuthenticatedPrincipal(HttpServletRequest httpServletRequest) {
        return verifyApiKey(httpServletRequest.getHeader(principalRequestHeader))?.principal
    }

    @Override
    protected Object getPreAuthenticatedCredentials(HttpServletRequest httpServletRequest) {
        return verifyApiKey(httpServletRequest.getHeader(principalRequestHeader))?.credentials
    }


    private Authentication verifyApiKey(String apikey) {
        if (apikey && apikey.indexOf("SemKey ") == 0) {
            def semApiToken = semApiKeyRSAManager.decode(apikey.replace("SemKey ", ""))
            logger.debug "verifying apikey auth $apikey"
            logger.debug semApiToken as JSON
            if (semApiToken.exp < System.currentTimeMillis()) {
                return new SemApiKeyToken(semApiToken.sub, semApiToken);
            }
        }

        return null
    }
}
