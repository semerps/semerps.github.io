package grails.plugin.sem

import grails.converters.JSON
import grails.plugins.sem.SemApiKeyToken
import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken
import org.springframework.util.Assert
import org.springframework.beans.factory.InitializingBean

import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.core.userdetails.UserDetailsChecker
import org.springframework.security.core.Authentication
import org.springframework.security.core.AuthenticationException

import org.springframework.security.authentication.AuthenticationProvider
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.authentication.AccountStatusUserDetailsChecker

class SemApiKeyAuthenticationProvider implements AuthenticationProvider, InitializingBean {

    static final Log logger = LogFactory.getLog(SemApiKeyAuthenticationProvider.class);

    UserDetailsService userDetailsService;
    UserDetailsChecker userDetailsChecker = new AccountStatusUserDetailsChecker();

    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
//        SemApiKeyToken auth = (SemApiKeyToken) authentication;
        try {
            UserDetails userDetails = userDetailsService.loadUserByUsername(authentication.principal)
            UsernamePasswordAuthenticationToken result = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.authorities)
            this.userDetailsChecker.check(userDetails)
            result.setDetails(userDetails)
            return result;
        } catch (java.lang.Exception e) {
            e.printStackTrace()
            throw e;
        }
    }


    boolean supports(Class<? extends Object> auth) {
        return SemApiKeyToken.class.isAssignableFrom(auth) || PreAuthenticatedAuthenticationToken.class.isAssignableFrom(auth)
    }


    void afterPropertiesSet() throws Exception {
        Assert.notNull(this.userDetailsService, "userDetailsService must be specified");
    }

}