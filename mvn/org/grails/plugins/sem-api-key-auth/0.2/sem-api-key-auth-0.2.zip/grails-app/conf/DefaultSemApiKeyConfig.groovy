security {
	semapikey {
		// activate semapikey plugin
		active = false

        token {
            timeout = 14400
            privateKey = null
        }

        filter {
            redirectUrl = '/'
            processesUrl = '/j_spring_semapi_security_check'
        }

        apiKeyAuthenticationEnabled = true
    }
}