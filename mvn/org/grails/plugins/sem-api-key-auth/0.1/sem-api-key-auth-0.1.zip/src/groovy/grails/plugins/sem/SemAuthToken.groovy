package grails.plugin.sem

class SemAuthToken {
    String sub
    Long exp
}