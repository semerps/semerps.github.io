package grails.plugin.sem

import java.security.spec.InvalidKeySpecException
import java.security.spec.X509EncodedKeySpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.NoSuchAlgorithmException
import java.security.KeyFactory
import java.security.PublicKey
import java.security.PrivateKey


import java.util.Base64
import groovy.json.JsonSlurper
import javax.crypto.Cipher

class SemApiKeyRSAManager {

    private String base64PrivateKey = ""

    public void setBase64PrivateKey(String base64PrivateKey) {
        this.base64PrivateKey = base64PrivateKey
    }

    def getPrivateKey() {
        PrivateKey privateKey = null;
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
        KeyFactory keyFactory = null;
        try {
            keyFactory = KeyFactory.getInstance("RSA");
            privateKey = keyFactory.generatePrivate(keySpec);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return privateKey;
    }

    def getPublicKey(String base64PublicKey){
        PublicKey publicKey = null;
        try{
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            publicKey = keyFactory.generatePublic(keySpec);
            return publicKey;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return publicKey;
    }


    def encode(String raw, String base64PublicKey) {
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding")
	    cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(base64PublicKey))
	    byte[] data = cipher.doFinal(raw.getBytes())
        return Base64.getEncoder().encodeToString(data)
    }

    def decode(String encoded) {
        byte[] data = Base64.getDecoder().decode(encoded)
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        String json = new String(cipher.doFinal(data));

        def slurper = new JsonSlurper()
        def result = slurper.parseText(json)
        return result
    }
}

