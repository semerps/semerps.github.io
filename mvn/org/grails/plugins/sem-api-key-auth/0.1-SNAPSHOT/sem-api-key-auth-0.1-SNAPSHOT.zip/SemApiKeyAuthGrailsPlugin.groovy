import grails.plugin.sem.SemApiKeyRSAManager
import grails.plugin.sem.SemApiKeyAuthenticationProcessingFilter
import grails.plugin.sem.SemApiKeyAuthenticationProvider


import grails.plugin.springsecurity.SecurityFilterPosition
import grails.plugin.springsecurity.SpringSecurityUtils

import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler


class SemApiKeyAuthGrailsPlugin {
    // the plugin version
    def version = "0.1-SNAPSHOT"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "2.5 > *"
    // resources that are excluded from plugin packaging

    def loadAfter = ['springSecurityCore'] 

    def pluginExcludes = [
        "grails-app/views/error.gsp"
    ]

    // TODO Fill in these fields
    def title = "Sem Api Key Auth Plugin" 
    def author = "Selami Altin"
    def authorEmail = "selamialtin@gmail.com"
    def description = '''\
Brief summary/description of the plugin.
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugin/sem-api-key-auth"

    // Extra (optional) plugin metadata

    // License: one of 'APACHE', 'GPL2', 'GPL3'
//    def license = "APACHE"

    // Details of company behind the plugin (if there is one)
//    def organization = [ name: "My Company", url: "http://www.my-company.com/" ]

    // Any additional developers beyond the author specified above.
//    def developers = [ [ name: "Joe Bloggs", email: "joe@bloggs.net" ]]

    // Location of the plugin's issue tracker.
//    def issueManagement = [ system: "JIRA", url: "http://jira.grails.org/browse/GPMYPLUGIN" ]

    // Online location of the plugin's browseable source code.
//    def scm = [ url: "http://svn.codehaus.org/grails-plugins/" ]

    def doWithWebDescriptor = { xml ->
        // TODO Implement additions to web.xml (optional), this event occurs before
    }

    def doWithSpring = {
		def conf = SpringSecurityUtils.securityConfig
		if (!conf || !conf.active) {
			return
		}

		SpringSecurityUtils.loadSecondaryConfig 'DefaultSemApiKeyConfig'

		conf = SpringSecurityUtils.securityConfig

		if (!conf.semapikey.active) {
			return
		}

        if (conf.semapikey.apiKeyAuthenticationEnabled) {
            println "... semapikey registering providers"
            SpringSecurityUtils.registerProvider 'semApiKeyAuthenticationProvider'
            SpringSecurityUtils.registerFilter 'semApiKeyAuthenticationProcessingFilter', SecurityFilterPosition.OPENID_FILTER
        }

        semApiKeyRSAManager(SemApiKeyRSAManager) {
            base64PrivateKey = conf.semapikey.token.privateKey
        }

        semApiKeyAuthenticationProcessingFilter(SemApiKeyAuthenticationProcessingFilter) {
			semApiKeyRSAManager = ref('semApiKeyRSAManager')
            rememberMeServices = ref('rememberMeServices')
			authenticationManager = ref('authenticationManager')
            authenticationDetailsSource = ref('authenticationDetailsSource')
			sessionAuthenticationStrategy = ref('sessionAuthenticationStrategy')
			authenticationSuccessHandler = new SimpleUrlAuthenticationSuccessHandler(conf.semapikey.filter.redirectUrl as String)
			//authenticationSuccessHandler = ref('authenticationSuccessHandler')
			authenticationFailureHandler = ref('authenticationFailureHandler')
            if (conf.semapikey.filter.processesUrl) {
                filterProcessesUrl = conf.semapikey.filter.processesUrl as String
            }
		}

        semApiKeyAuthenticationProvider(SemApiKeyAuthenticationProvider) {
			userDetailsService = ref('userDetailsService')
		}

    }

    def doWithDynamicMethods = { ctx ->
        // TODO Implement registering dynamic methods to classes (optional)
    }

    def doWithApplicationContext = { ctx ->
        // TODO Implement post initialization spring config (optional)
    }

    def onChange = { event ->
        // TODO Implement code that is executed when any artefact that this plugin is
        // watching is modified and reloaded. The event contains: event.source,
        // event.application, event.manager, event.ctx, and event.plugin.
    }

    def onConfigChange = { event ->
        // TODO Implement code that is executed when the project configuration changes.
        // The event is the same as for 'onChange'.
    }

    def onShutdown = { event ->
        // TODO Implement code that is executed when the application shuts down (optional)
    }
}
