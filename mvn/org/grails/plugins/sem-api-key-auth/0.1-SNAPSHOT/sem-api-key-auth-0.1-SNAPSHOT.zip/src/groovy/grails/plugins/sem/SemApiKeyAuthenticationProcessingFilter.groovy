package grails.plugin.sem

import grails.converters.JSON

import grails.plugin.springsecurity.SpringSecurityUtils

import javax.servlet.ServletException

import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.servlet.http.HttpSession

import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter
import org.springframework.security.core.Authentication
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.authentication.BadCredentialsException
import org.springframework.security.authentication.DisabledException
import org.springframework.security.web.util.TextEscapeUtils
import org.springframework.util.Assert

class SemApiKeyAuthenticationProcessingFilter extends AbstractAuthenticationProcessingFilter {

    static final Log logger = LogFactory.getLog(getClass());

    SemApiKeyRSAManager semApiKeyRSAManager

    SemApiKeyAuthenticationProcessingFilter() {
        super('/j_spring_semapi_security_check')
    }

    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) {
        logger.debug "SemApiKeyAuthenticationProcessingFilter auth"

        String username = request.getParameter("username")
        String apikey = request.getParameter("apikey")

        try {
            def token = verifyApiKey(username, apikey)

            if (token) {
                // Place the last username attempted into HttpSession for views
                HttpSession session = request.getSession(false);
                if ((session != null) || (getAllowSessionCreation())) {
                    session = request.getSession(); 
                    session.setAttribute("SPRING_SECURITY_LAST_USERNAME", TextEscapeUtils.escapeEntities(username));
                }
                
                // Allow subclasses to set the "details" property
                setDetails(request, token);
                
                //calling authentication manager
                Authentication authentication = authenticationManager.authenticate(token);
                if (authentication.authenticated) {
                    logger.debug "Successful authentication"
                    return authentication
                } else {
                    throw new DisabledException("User is disabled")
                }
            }            
        } catch (Exception e) {
            logger.error "Failed processing semapi callback", e
        }
        throw new BadCredentialsException("Invalid semapi key")
    }

    @Override
	public void afterPropertiesSet() {
		Assert.notNull(authenticationManager, "authenticationManager must be specified");
		Assert.notNull(semApiKeyRSAManager, "semApiKeyRSAManager must be specified");
	}

    Authentication verifyApiKey(String username, String apikey) {
        def semApiToken = semApiKeyRSAManager.decode(apikey)
        logger.debug "verifying apikey $apikey" 
        logger.debug semApiToken as JSON
        if (semApiToken.exp < System.currentTimeMillis()) {
            if (semApiToken.sub == username) {
                return new UsernamePasswordAuthenticationToken(semApiToken.sub, apikey);  
            }   
            logger.error "semapikey subject and username is not equal"
            return null 
        }

        return null
    }


	void setDetails(HttpServletRequest request, UsernamePasswordAuthenticationToken authRequest) {
		authRequest.setDetails(this.authenticationDetailsSource.buildDetails(request));
	}

}
