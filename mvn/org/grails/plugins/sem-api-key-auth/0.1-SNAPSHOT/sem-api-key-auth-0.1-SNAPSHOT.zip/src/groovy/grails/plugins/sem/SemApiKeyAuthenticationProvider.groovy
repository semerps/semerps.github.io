package grails.plugin.sem

import grails.converters.JSON

import org.apache.commons.logging.Log
import org.apache.commons.logging.LogFactory

import org.springframework.util.Assert
import org.springframework.beans.factory.InitializingBean

import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.core.userdetails.UserDetailsChecker
import org.springframework.security.core.Authentication
import org.springframework.security.core.AuthenticationException

import org.springframework.security.authentication.AuthenticationProvider
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.authentication.AccountStatusUserDetailsChecker

class SemApiKeyAuthenticationProvider implements AuthenticationProvider, InitializingBean {

    static final Log logger = LogFactory.getLog(SemApiKeyAuthenticationProvider.class);

    UserDetailsService userDetailsService;
    UserDetailsChecker userDetailsChecker = new AccountStatusUserDetailsChecker();

    public SemApiKeyAuthenticationProvider() {
    }

    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        UsernamePasswordAuthenticationToken auth = (UsernamePasswordAuthenticationToken) authentication;
        try {
            UserDetails userDetails = userDetailsService.loadUserByUsername(auth.name)
            UsernamePasswordAuthenticationToken result = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.authorities)
            this.userDetailsChecker.check(userDetails)
            result.setDetails(userDetails)
            return result;
        } catch (java.lang.Exception e) {
            e.printStackTrace()
            throw e;
        }
    }


    boolean supports(Class<? extends Object> auth) {
        return UsernamePasswordAuthenticationToken.class.isAssignableFrom(auth);
    }


    void afterPropertiesSet() throws Exception {
        Assert.notNull(this.userDetailsService, "userDetailsService must be specified");
    }

}