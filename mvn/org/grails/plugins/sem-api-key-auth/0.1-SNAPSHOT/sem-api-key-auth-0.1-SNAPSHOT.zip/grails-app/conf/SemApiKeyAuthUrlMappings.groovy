import grails.plugin.springsecurity.SpringSecurityUtils

class SemApiKeyAuthUrlMappings {

	static mappings = {
        "/semapiauth/auth-token"(controller: "apiKey", action: "authToken")
        "/semapiauth/api-token"(controller: "apiKey", action: "apiToken")
        "/semapiauth/api-login"(controller: "apiKey", action: "login")
	}
}
