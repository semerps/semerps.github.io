package grails.plugin.sem

import grails.converters.JSON

import javax.servlet.http.HttpServletResponse

import org.springframework.security.core.userdetails.UsernameNotFoundException

import grails.plugin.springsecurity.SpringSecurityUtils

class ApiKeyController {

    def apiKeyService
    def springSecurityService


    def apiToken() {
        render([error: g.message(code: 'semapikey.tokenRequest.userNotValid', args: ['not supported yet'])] as JSON)
    }
    

    def authToken() {
        def key = params.key
        def username = params.username
        if (!key) {
            render([error: g.message(code: 'semapikey.tokenRequest.key.required')] as JSON)
        } else if (!username) {
            render([error: g.message(code: 'semapikey.tokenRequest.username.required')] as JSON)
        } else {
            try {
                render ([token: apiKeyService.getAuthToken(key, username)] as JSON)
            } catch (UsernameNotFoundException e) {
                render([error: g.message(code: 'semapikey.tokenRequest.usernameNotFound')] as JSON)
            } catch (Exception e) {
                render([error: g.message(code: 'semapikey.tokenRequest.userNotValid', args: [e.message])] as JSON)
            }
        }    
    }

    def login() {
        if (springSecurityService.isLoggedIn()) {
            redirect uri: (SpringSecurityUtils.securityConfig.semapikey.filter.redirectUrl as String), params: params
        } else {
            redirect uri: (SpringSecurityUtils.securityConfig.semapikey.filter.processesUrl as String), params: params
        }
    }

    
}