package grails.plugin.sem

import grails.converters.JSON

import grails.plugin.springsecurity.SpringSecurityUtils
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UserDetailsService

class ApiKeyService {

    def semApiKeyRSAManager
    def userDetailsService

    def getApiToken(String key, String userId) {
        try {
            UserDetails userDetails = userDetailsService.loadUserByUsername(userId)
            String token = (new SemAuthToken(sub: userDetails.username, exp: tokenTimeout)) as JSON
            return semApiKeyRSAManager.encode(token, key)        
        } catch (Exception e){
             e.printStackTrace()
            throw e;
        }
    }

    def getAuthToken(String key, String userId) {
        try {
            UserDetails userDetails = userDetailsService.loadUserByUsername(userId)
            String token = (new SemAuthToken(sub: userDetails.username, exp: tokenTimeout)) as JSON
            return semApiKeyRSAManager.encode(token, key)        
        } catch (Exception e){
             e.printStackTrace()
            throw e;
        }
    }


	protected ConfigObject getSecurityConfig() { 
        return SpringSecurityUtils.securityConfig 
    }

    protected int getTokenTimeout() { 
        return System.currentTimeMillis() + Long.valueOf(securityConfig.semapikey.token.timeout)
    }
    
}